<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
/**

 **/
class tablero_status extends MX_Controller {

    /**

     **/
    public function __construct()
    {
        parent::__construct();

        $this->load->model('principal', '', TRUE);
        $this->load->model('bitacora_negocios_model', '', TRUE);
        $this->load->library(array('session'));
        $this->load->helper(array('form', 'html', 'companies', 'url'));

        //if(!$this->session->userdata('id')){redirect('login');}
        
        date_default_timezone_set('America/Mexico_City');
    }

	public function index(){

        $res["nada"] =  $this->bitacora_negocios_model->financiamiento_seguros_all(0);
        $res["json"] = json_encode($res["nada"]);


      //  $data['contactos'] = $this->principal->get_result('contactoIdAdmin',$this->session->userdata('id'),'contactos');//$this->principal->get_table('contactos');
        //$data['empresas'] = $this->principal->get_contactos_empresas_all();//get_contactos_empresas($this->session->userdata('id'));
       $this->load->view('bitacora_negocios/tablero_status', $res);
       

        //$content = $this->load->view('bitacora_negocios/m_agregar', '', false);
        //$content = $this->load->view('contactos/m_editar', '', false);

	}


   



}