<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Bitacora_negocios extends MX_Controller {
	 public function __construct()
    {
        parent::__construct();
        $this->load->model('principal', '', TRUE);
        $this->load->model('bitacora_negocios_model', '', TRUE);
        $this->load->library(array('session'));
        $this->load->helper(array('form', 'html', 'companies', 'url','date'));

        date_default_timezone_set('America/Mexico_City');
    }
    public function index(){
    	$datos['drop_asesores']=form_dropdown('id_asesor',array_combos($this->bitacora_negocios_model->asesor_vendedor_all(),'nombre','nombre',true),"",'class="form-control busqueda llenar_busqueda_select" id="id_asesor" ');

    	$datos['drop_clientes']=form_dropdown('id_cliente',array_combos($this->bitacora_negocios_model->getClientes(),'nombre_cliente','nombre_cliente',true),"",'class="form-control busqueda llenar_busqueda_select" id="id_cliente" ');

    	$datos['drop_financiera']=form_dropdown('id_financiera',array_combos($this->bitacora_negocios_model->getFinancieras(),'nombre','nombre',true),"",'class="form-control busqueda llenar_busqueda_select" id="id_financiera" ');

    	$datos['drop_status']=form_dropdown('id_status',array_combos($this->bitacora_negocios_model->getStatus(),'status','status',true),"",'class="form-control busqueda llenar_busqueda_select" id="id_status" ');


    	$content = $this->load->view('Bitacora_negocios/busquedas_inteligentes', $datos, TRUE);
        $this->load->view('main/panel', array('content'=>$content,
                                                       'included_js'=>array('')));
    }
	public function mostrar_graficas($tipo=1){
		//tipo uno cuando son las busquedas sin el rango de fechas
		if($tipo==1){
			$datos = $this->bitacora_negocios_model->getDatos();
		}else{
			$datos = $this->bitacora_negocios_model->getDatosByFecha();
		}	
		
		//print_r($this->db->last_query());die();
		$fechas = array();
		foreach ($datos as $key => $value) {
			$fechas[] = date2sql($value->fecha_recepcion_docs);
		}

		//print_r($fechas);die();
		//$array_final = $this->fecha(array('2017-10-01','2017-10-01','2017-10-31','2017-10-31','2017-10-31','2017-11-31'));
		$array_final = $this->fecha($fechas);

		if(!isset($array_final['p1'])){
			$datos_vista['p1'] = array(0,0,0,0,0,0,0,0,0,0,0,0);	
		}else{
			$datos_vista['p1'] = $array_final['p1'];	
		}


		if(!isset($array_final['p2'])){
			$datos_vista['p2'] = array(0,0,0,0,0,0,0,0,0,0,0,0);	;	
		}else{
			$datos_vista['p2'] = $array_final['p2'];	
		}


		if(!isset($array_final['p3'])){
			$datos_vista['p3'] = array(0,0,0,0,0,0,0,0,0,0,0,0);	;	
		}else{
			$datos_vista['p3'] =  $array_final['p3'];	
		}


		if(!isset($array_final['p4'])){
			$datos_vista['p4'] = array(0,0,0,0,0,0,0,0,0,0,0,0);	;	
		}else{
			$datos_vista['p4'] =  $array_final['p4'];	
		}
		$datos_vista['nombre_grafica'] = $this->input->post('nombre_grafica');
		echo $this->load->view('Bitacora_negocios/test', $datos_vista, TRUE);
        
	}
	public function fecha($fecha = array()){
		$array = array();
		$valorp1 = 0;
		$valorp2 = 0;
		$valorp3 = 0;
		$valorp4 = 0;
		foreach ($fecha as $key => $value) {
			//echo $value.'<br>';
			$dia = (int)date("d", strtotime($value));
			$mes = date("n", strtotime($value));
			if($dia>= 1 && $dia <=8){
				//periodo 1
				if(isset($array['p1'][$mes])){
					$valorp1 = $array['p1'][$mes] +1;
					$array['p1'][$mes] = $valorp1;
				}else{
					$array['p1'][$mes] = 1;
				}
			}else if($dia>= 9 && $dia <=16){
				//periodo 2
				if(isset($array['p2'][$mes])){
					$valorp2 = $array['p2'][$mes] +1;
					$array['p2'][$mes] = $valorp2;
				}else{
					$array['p2'][$mes] = 1;
				}
			}else if($dia>= 17 && $dia <=24){
				//periodo 3
				if(isset($array['p3'][$mes])){
					$valorp3 = $array['p3'][$mes] +1;
					$array['p3'][$mes] = $valorp3;
				}else{
					$array['p3'][$mes] = 1;
				}
			}else if($dia>= 25 && $dia <=31){
				//periodo 4
				if(isset($array['p4'][$mes])){
					$valorp4 = $array['p4'][$mes] +1;
					$array['p4'][$mes] = $valorp4;
				}else{
					$array['p4'][$mes] = 1;
				}
			}

		}
		
		$array_final = array();
		foreach ($array as $key => $value) {
			for ($i=1; $i <=12 ; $i++) { 
				if(isset($value[$i])){
					$array_final[$key][$i] = $value[$i];
				}else{
					$array_final[$key][$i] = 0;
				}
			}

		}
		return $array_final;
	}
}
?>