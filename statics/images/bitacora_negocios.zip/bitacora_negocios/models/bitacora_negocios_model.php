<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class bitacora_negocios_model extends CI_Model {


        public function save_financiamiento_seguros_row($fs)
        {
        	     $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

                $data = array(
                     'nombre' => $fs["financiera"] 
  
                );

                $this->db->insert('bitacora_negocios', $fs);
                $query = $this->db->get_where('financiera', array('nombre' => $fs["financiera"]));
                $query->num_rows() == 0 ? $this->db->insert('financiera', $data) : false;
                $data = $this->db->get('bitacora_negocios');
                return $data->result();
        }

        public function financiamiento_seguros_all($status = array())
        {
              // 1 es finalizada, 0 no
               $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

               
                $data = $this->db->where_in('finalizado',$status)->get('bitacora_negocios');
                return $data->result();
        }

        public function asesor_vendedor_all()
        {
               $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

                $data = $this->db->select('a.id,a.nombre,ca.categoria')->join('categoria_asesor ca','a.id_categoria_asesor = ca.id')->order_by('ca.categoria')->get('asesor_vendedor a');
                return $data->result();
        }


        public function hora_intervalos_all()
        {
               $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

                $data = $this->db->get('hora_intervalo');
                return $data->result();
        }

        public function financieras_all()
        {
               $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

               
                $data = $this->db->get('financiera');
                return $data->result();
        }

        public function estatus_tramite_all()
        {
               $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

               
                $data = $this->db->get('estatus_tramite');
                return $data->result();
        }

        public function aseguradoras_all()
        {
               $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

               
                $data = $this->db->get('aseguradora');
                return $data->result();
        }

        public function comisiones_all()
        {
               $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

               
                $data = $this->db->get('porcentaje_comision');
                return $data->result();
        }

        public function udi_all()
        {
               $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

               
                $data = $this->db->get('udi');
                return $data->result();
        }

         public function modelos_all()
        {
               $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

               
                $data = $this->db->get('modelos');
                return $data->result();
        }

        public function asesores_all()
        {
               $this->load->database();
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

               
                $data = $this->db->order_by('nombre')->get('asesor_vendedor');
                return $data->result();
        }

      public function update_bitacora_negocios_row($fs)
        {
               $this->load->database();


          $data = array(
                     'nombre' => $fs["financiera"] 
  
          );

        $query = $this->db->get_where('financiera', array('nombre' => $fs["financiera"]));
        $query->num_rows() == 0 ? $this->db->insert('financiera', $data) : false;

         $this->db->where('id', $fs["id"]);
          $this->db->update('bitacora_negocios', $fs);

// Produces:
//
//      UPDATE mytable
//      SET title = '{$title}', name = '{$name}', date = '{$date}'
//      WHERE id = $id
              
        }

        public function get_bitacora_negocios($id)
        {
              
               $id = intval($id);
               /* $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();*/

                $query = $this->db->get_where('bitacora_negocios', array('id' => $id));
               
                //$data = $this->db->get('modelos');
                return $query->result();
        }
        //obtiene graficas
        public function getDatos(){
          
          //SELECT STR_TO_DATE('5/16/2011', '%c/%e/%Y')
          if($this->input->post('anio')!=''){
            $anio = $this->input->post('anio');
          }else{
            $anio = date('Y');
          }

           if($this->input->post('mes')!=''){
            $mes = $this->input->post('mes');
            // $fecha_inicio = $anio.'/'.$mes.'/01';
            // $fecha_fin = $anio.'/'.$mes.'/31';
            $fecha_inicio = "01/".$mes."/".$anio;
            $fecha_fin = "31/".$mes."/".$anio;
          }else{
            // $fecha_inicio = $anio.'/01/01';
            // $fecha_fin = $anio.'/12/31';
              $fecha_inicio = '01/01/'.$anio;
             $fecha_fin = '31/12/'.$anio;
          }
          //var_dump($fecha_inicio,$fecha_fin);die();
           $this->db->where('fecha_recepcion_docs >=',$fecha_inicio);
           $this->db->where('fecha_recepcion_docs <=',$fecha_fin);
          return $this->db->where($this->input->post('tipo_busqueda'),$this->input->post('abuscar'))->select('id,fecha_recepcion_docs')->get('bitacora_negocios')->result();
        }
         //obtiene graficas por fechas
        public function getDatosByFecha(){
          $campo_buscar = $this->input->post('tipo_busqueda');
           $this->db->where($campo_buscar.' >=',$this->input->post('finicio'));
           $this->db->where($campo_buscar.' <=',$this->input->post('ffin'));
          return $this->db->select('id,'.$campo_buscar)->get('bitacora_negocios')->result();
        }
        public function getClientes(){
          return $this->db->select('distinct(nombre_cliente)')->order_by('nombre_cliente')->get('bitacora_negocios')->result();
        }
        public function getStatus(){
          return $this->db->select('distinct(status)')->order_by('status')->get('bitacora_negocios')->result();
        }
        public function getFinancieras(){
          return $this->db->order_by('nombre')->get('financiera')->result();
        }


     

}