<link href="<?php echo base_url();?>statics/css/tema/css/plugins/clockpicker/clockpicker.css" rel="stylesheet">
<link href="<?php echo base_url();?>statics/css/tema/css/plugins/clockpicker/clockpicker.css" rel="stylesheet">
<link href="<?php echo base_url();?>statics/css/bootstrap/css/bootstrap-switch.css" rel="stylesheet">

<!-- Color picker -->
<script src="<?php echo base_url();?>statics/css/tema/js/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>

<!-- Clock picker -->
<script src="<?php echo base_url();?>statics/css/tema/js/plugins/clockpicker/clockpicker.js"></script>

<script src="<?php echo base_url();?>statics/css/tema/js/plugins/daterangepicker/daterangepicker.js"></script>

 <script src="<?php echo base_url();?>statics/css/tema/js/plugins/datapicker/bootstrap-datepicker.js"></script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>

<script src="<?php echo base_url();?>statics/js/modules/bootstrap-datetimepicker.js"></script>

<script src="<?php echo base_url();?>statics/css/bootstrap/js/bootstrap-switch.js"></script>


<script src="<?php echo base_url();?>statics/js/custom/bootbox.min.js"></script>

<script src="<?php echo base_url();?>statics/js/custom/general.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/js/select2.min.js"></script>
<script>



$(document).ready(function(){

  //$(".form-control").attr('required','required');
   $('.asesores').select2();
  var records =    <?php Print($json); ?>;

  $('.clockpicker').clockpicker();

   $('.datepicker').datepicker({
     format: 'dd/mm/yyyy',

   });
    mensaje="<?php echo $this->session->flashdata('msg') ?>";
     if(mensaje!=''){
      ExitoCustom(mensaje,2);
     }
  /*$("input[name*='fecha_aprobacion']" ).mask('00/00/0000');
  $("input[name*='fecha_condicionamiento']" ).mask('00/00/0000');
  $("input[name*='fecha_contrato']" ).mask('00/00/0000');
  $("input[name*='fecha_compra']" ).mask('00/00/0000');
  $("input[name*='fecha_cumplimiento']" ).mask('00/00/0000');
  $("input[name*='fecha_recepcion_docs']" ).mask('00/00/0000');
  $("input[name*='vencimiento_anual']" ).mask('00/00/0000');
  $("input[name*='inicio_vigencia']" ).mask('00/00/0000');
  $("input[name*='emision']" ).mask('00/00/0000');

  $("input[name*='hora_condicion']" ).mask('00:00');
  $("input[name*='hora_cumplimiento']" ).mask('00:00');
  $("input[name*='hora_contrato']" ).mask('00:00');
  $("input[name*='hora_compra']" ).mask('00:00');
  $("input[name*='hora_aprobacion']" ).mask('00:00');
  $("input[name*='hora_recepcion_docs']" ).mask('00:00');
  $("input[name*='hora_inicio_analisis']" ).mask('00:00');*/








  $("#input-precio-unidad").maskMoney();
  $("#input-enganche").maskMoney();
  $("#prima-total").maskMoney();
  $("#emision-poliza").maskMoney();



$('#data_1 .input-group.date').datepicker({
    todayBtn: "linked",
    keyboardNavigation: false,
    forceParse: false,
    calendarWeeks: true,
    autoclose: true
});

$( "#btn-busquedas" ).click(function() {
  $('#my-final-table').dynatable({
   table: {
        defaultColumnIdStyle: 'camelCase'
    },
  dataset: {
    records: records
  }

   }).bind('dynatable:afterUpdate', processingComplete());

$("#dynatable-query-search-my-final-table").on('keyup', function (e) {
    if (e.keyCode == 13) {

       var txt = $("#dynatable-query-search-my-final-table");
                if (txt.val() != null && txt.val() != '') {
                   $('#my-final-table').show();
                   $("#dynatable-pagination-links-my-final-table").show();
                   $("#dynatable-record-count-my-final-table").show();

                } else {
                   $('#my-final-table').hide();
                   $("#dynatable-pagination-links-my-final-table").hide();
                   $("#dynatable-record-count-my-final-table").hide();
                }




    }
});


});

$("#input-comision-agencia").on("change paste keyup", function() {
   var val = $(this).val();
   var comision = val * 0.30;
   $("#input-comision-asesor").val(comision);
});

$("#input-precio-unidad").on("change paste keyup", function() {
   var financiar;
   var precioUnidad = $(this).val();

  precioUnidad = precioUnidad.replace(",","");

   var enganche = $.trim($("#input-enganche").val());
   if(enganche.length == 0)
    {
       enganche = 0;
       $("#input-monto-financiar").val(precioUnidad);
    }

    else{

      enganche = enganche.replace(",","");

      financiar = precioUnidad - enganche;
    }
    $("#input-monto-financiar").val(financiar);

    var monto= $("#input-monto-financiar").val()
    var porcentaje = $( "#porcentaje-comision option:selected" ).text();
        porcentaje = porcentaje.replace("%","");
        porcentaje = porcentaje / 100;

     comAgencia = monto * porcentaje;
     $("#input-comision-agencia").val(comAgencia);


     var comAsesor = comAgencia * 0.3;
     $("#input-comision-asesor").val(comAsesor);



});

$("#input-enganche").on("change paste keyup", function() {
   var enganche = $(this).val();
   var precioUnidad = $("#input-precio-unidad").val();

   enganche = enganche.replace(",","");
   precioUnidad = precioUnidad.replace(",","");

   var financiar = precioUnidad - enganche

   $("#input-monto-financiar").val(financiar);

    var monto = $("#input-monto-financiar").val();
    var porcentaje = $( "#porcentaje-comision option:selected" ).text();
    porcentaje = porcentaje.replace("%","");
    porcentaje = porcentaje / 100;
    var comisionAgencia = 1*(monto * porcentaje)
    $("#input-comision-agencia").val(comisionAgencia);
    var comisionAsesor = comisionAgencia * 0.3;
    $("#input-comision-asesor").val(comisionAsesor);


});

$("#porcentaje-comision").change(function () {
        //var end = this.value;
        var monto = $("#input-monto-financiar").val();
        var porcentaje = $( "#porcentaje-comision option:selected" ).text();
        porcentaje = porcentaje.replace("%","");
        porcentaje = porcentaje / 100;
        var comisionAgencia = 1*(monto * porcentaje)
        $("#input-comision-agencia").val(comisionAgencia);
        var comisionAsesor = comisionAgencia * 0.3;
        $("#input-comision-asesor").val(comisionAsesor);
    });


$('#select-financiera').append(new Option('OTROS', 'OTROS', false, false));

$( "#select-financiera" ).change(function() {
  var val = $( "#select-financiera option:selected" ).val();
    if(val=="OTROS"){

      var financiera = prompt("Ingresa el nombre de la financiera a agregar");
      if(financiera != null)
         $("#select-financiera option:last").before("<option value='"+financiera+"' selected='selected' >"+financiera+"</option>");
       else
        $('#select-financiera option:first-child').attr("selected", "selected");

   }
});

$("#prima-total").on("change paste keyup", function() {
   var primaTotal = $(this).val();
   primaTotal = primaTotal.replace(",","");
   var iva = $("#iva").val();
   iva = primaTotal * 0.16;
   $("#iva").val(iva);

   var emisionPoliza =  $("#emision-poliza").val();
   emisionPoliza = emisionPoliza.replace(",","");
   var primaNeta = primaTotal - iva - emisionPoliza;
   $("#prima-neta").val(primaNeta);

   var comisionAgencia = primaNeta * 0.24;
   $("#udi-agencia").val(comisionAgencia);

   var comisionAsesor = comisionAgencia * 0.30;
   $("#comision-asesor-prima").val(comisionAsesor);





});

$("#emision-poliza").on("change paste keyup", function() {
   var emisionPoliza = $(this).val();
   var primaTotal = $("#prima-total").val();
   var iva = $("#iva").val();

   primaTotal = primaTotal.replace(",","");
   emisionPoliza = emisionPoliza.replace(",","");
   iva = iva.replace(",","");

   var primaNeta = primaTotal - emisionPoliza - iva;
   $("#prima-neta").val(primaNeta);

   var comisionAgencia = primaNeta * 0.24;
   $("#udi-agencia").val(comisionAgencia);

   var comisionAsesor = comisionAgencia * 0.30;
   $("#comision-asesor-prima").val(comisionAsesor);





});

$("[name='my-checkbox']").bootstrapSwitch({
    onColor:"success",
    offColor:'danger',
    onText:"Si",
    offText: "No"
});
  $("[name='my-checkbox']").on('switchChange.bootstrapSwitch', function(event, state) {
    console.log(state); // true | false
    if(state){
      $("#finalizado").val(1);
    }else{
       $("#finalizado").val(0);
    }
    
  });
  //$("[name='my-checkbox']").bootstrapSwitch('state', false, false);
});

function processingComplete (){
        $('#my-final-table').hide();
        $("#dynatable-pagination-links-my-final-table").hide();
        /*$("#dynatable-search-my-final-table").html('Buscar: <input type="search" id="dynatable-query-search-my-final-table" data-dynatable-query="search" value="escape">');
        $("a.dynatable-page-prev ").html('Anterior');
        $("a.dynatable-page-next ").html('Siguente');
        $("span.dynatable-per-page-label").html('Mostrar');
        $("#dynatable-pagination-links-my-final-table li span").html('Paginas:');*/

        $('#my-final-table thead tr').each(function() {
             var $tdd =  '<th data-dynatable-column="Editar" class="dynatable-head">'+'<button id="" class="btn btn-sm btn-primary text-center m-t-n-xs" data-toggle="modal" data-target="#myModalEdit"><strong>Editar</strong></button></th>';


            $(this).append($tdd);

        });

         $('#my-final-table tbody tr').each(function() {
             var $tdd =  '<td>'+'<button id="" class="btn btn-sm btn-primary text-center m-t-n-xs" data-toggle="modal" data-target="#myModalEdit"><strong>Editar</strong></button>'+'</td>';


            $(this).append($tdd);

        });






}
</script>





<h3>Seguros y financiamiento</h3>
<div class="row">
  <div class="col-sm-12">
    <div class="modal-dialog1">
        <div class="modal-content1">
            <div class="modal-body1">
              <div class="row">
                <div class="col-sm-8">
                  <h2>Datos de contacto para el cliente</h2>
                </div>
                 <div class="col-sm-2 pull-right form-group">
                      <label>¿Finalizado?</label>
                      <input type="checkbox" name="my-checkbox" class="bootstrap-switch-success">
                  </div>
              </div>

                  <div class="row">
                     <div class="col-sm-4">
                       <div>
                         <a type="button" class="btn btn-sm btn-primary text-center m-t-n-xs"
                                   href="<?php echo base_url(); ?>index.php/bitacora_negocios/busquedas " target="_blank">Busquedas</a>
                       <a type="button" class="btn btn-sm btn-success text-center m-t-n-xs" href="<?php echo base_url(); ?>index.php/bitacora_negocios/busquedas_inteligentes " target="_blank">Busquedas inteligentes</a>
                         
                       </div>
                       
                    </div>
                   
                   </div>


              <form role="form" action="<?php echo base_url();?>index.php/bitacora_negocios/save_financiamiento_seguros" method="post">
                <input type="hidden" id="finalizado" name="fs[finalizado]" value="0">
              <div class="row">

                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Asesor</label>
                    <select class="form-control asesores" name="fs[asesor]">
                     <?php
                        $json_obj = json_decode( $json_asesores, true );
                          foreach( $json_obj as $key => $value){
                            echo "<option value='".$value["nombre"]."'> ".$value["nombre"]."</option>";
                          }
                      ?>

                    </select>
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Nombre del ciente</label>
                    <input class="form-control" name="fs[nombre_cliente]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Tel casa</label>
                    <input class="form-control" name="fs[tel_casa]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Movil</label>
                    <input class="form-control" name="fs[movil]" />
                  </div>
                </div>
              </div>




              <div class="row">

                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Tel oficina</label>
                    <input class="form-control" name="fs[tel_oficina]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Correo electrónico</label>
                    <input class="form-control" name="fs[correo_electronico]" />
                  </div>

                </div>
                <div class="col-sm-3">

                </div>
              </div>

            </div>
        </div>
    </div>
  </div>
</div>



  <!-- INICIO SEGUNDO FORMULARIO -->




  <div class="row">
    <div class="col-sm-12">
      <div class="modal-dialog1">
          <div class="modal-content1">
              <div class="modal-body1">
                <h2>Inicio de medición del tiempo</h2>
                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Mes</label>
                      <select class="form-control" name="fs[mes]">
                        <option value="Enero">Enero</option>
                        <option value="Febrero">Febrero</option>
                        <option value="Marzo">Marzo</option>
                        <option value="Abril">Abril</option>
                        <option value="Mayo">Mayo</option>
                        <option value="Junio">Junio</option>
                        <option value="Julio">Julio</option>
                        <option value="Agosto">Agosto</option>
                        <option value="Septiembre">Septiembre</option>
                        <option value="Octubre">Octubre</option>
                        <option value="Noviembre">Noviembre</option>
                        <option value="Diciembre">Diciembre</option>
                      </select>

                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de Recepcion Dcts</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_recepcion_docs]">
                        </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de Recepcion Dcts</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input  type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_recepcion_docs]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de inicio del análisis</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_inicio_analisis]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                </div>




                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Comentarios</label>
                      <input class="form-control" name="fs[comentarios]" />
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Modelo</label>
                      <select class="form-control" name="fs[modelo]">
                      <?php
                        $json_obj = json_decode( $json_modelos, true );
                          foreach( $json_obj as $key => $value){
                            echo "<option value='".$value["modelo"]."'> ".$value["modelo"]."</option>";
                          }
                      ?>
                      </select>
                    </div>
                  </div>

                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Financiera</label>
                      <select id="select-financiera" class="form-control" name="fs[financiera]">
                        <?php
                           $json_obj = json_decode( $json_financieras, true );
                          foreach( $json_obj as $key => $value){
                            echo "<option value='".$value["nombre"]."'> ".$value["nombre"]."</option>";
                          }
                      ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Estatus</label>
                      <select class="form-control" name="fs[status]">
                        <option value="Recibido">Recibido</option>
                        <option value="Análisis">Análisis</option>
                        <option value="Condición">Condición</option>
                        <option value="En Reconsideración">En Reconsideración</option>
                        <option value="Aprobado">Aprobado</option>
                        <option value="Contrato Generado">Contrato Generado</option>
                        <option value="Validación Enganche">Validación Enganche</option>
                        <option value="Pago Plan piso">Pago Plan piso</option>
                        <option value="Envio Compra">Envio Compra</option>
                        <option value="Rechazo">Rechazo</option>
                        <option value="Comprada">Comprada</option>
                        <option value="Canceló">Canceló</option>
                        <option value="Refacturación">Refacturación</option>
                        <option value="Desembolso">Desembolso</option>
                      </select>
                    </div>

                  </div>
                </div>


                <div class="row">

                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Propuesta/Folio/contrato</label>
                      <input class="form-control" name="fs[propuesta_folio_contrato]" />
                    </div>
                  </div>


                </div>
              </div>
          </div>
      </div>
    </div>
  </div>

  <!-- FIN DE SEGUNDO FORMULARIO -- >


<!-- INICIO TERCER FORMULARIO -->

  <div class="row">
    <div class="col-sm-12">
      <div class="modal-dialog1">
          <div class="modal-content1">
              <div class="modal-body1">
                <h2>Medición del tiempo</h2>
                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de condicionamiento</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_condicionamiento]">
                        </div>
                    </div>
                  </div>
                   <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de condicionamiento</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_condicion]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de cumplimiento</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_cumplimiento]">
                        </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de cumplimiento</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_cumplimiento]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                </div>




                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de aprobación</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_aprobacion]">
                        </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de aprobación</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_aprobacion]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de contrato</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_contrato]">
                        </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de contrato</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_contrato]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                </div>



                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Estatus plan piso</label>
                      <select  class="form-control" name="fs[estatus_plan_piso]">
                        <option value="Unidad propia">Unidad propia</option>
                        <option value="Intercambio">Intercambio</option>
                        <option value="Se debe">Se debe</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de compra</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_compra]">
                        </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de compra</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_compra]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Comentarios contrato/compra</label>
                      <input class="form-control" name="fs[comentarios_contrato_compra]" />
                    </div>
                  </div>
                </div>


              </div>
          </div>
      </div>
    </div>
  </div>




<!-- FIN TERCER FORMULARIO -->

<!-- INICIO DEL CUARTO FORMULARIO -->

  <div class="row">
  <div class="col-sm-12">
    <div class="modal-dialog1">
        <div class="modal-content1">
            <div class="modal-body1">
              <h2>Administración de utilidad</h2>
              <div class="row">
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Nombre del plan</label>
                    <input class="form-control" name="fs[nombre_plan]" />
                  </div>
                </div>

                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Bono FC</label>
                    <input class="form-control" name="fs[bono_fc]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Plazo</label>
                    <input class="form-control" name="fs[plazo]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Precio unidad</label>
                    <input id="input-precio-unidad" class="form-control" name="fs[precio_unidad]" />
                  </div>
                </div>
              </div>


              <div class="row">
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Enganche</label>
                    <input id="input-enganche" class="form-control" name="fs[enganche]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Monto a financiar</label>
                    <input id="input-monto-financiar" class="form-control" name="fs[monto_financiar]" readonly/>
                  </div>
                </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>% Comision</label>
                      <select id="porcentaje-comision" class="form-control" name="fs[comision]">
                        <option value="0%">0%</option>
                        <option value="0.5%">0.5%</option>
                        <option value="1.0%">1.0%</option>
                        <option value="1.5%">1.5%</option>
                        <option value="2%">2%</option>
                        <option value="3%">3%</option>
                        <option value="4%">4%</option>
                        <option value="5%">5%</option>
                      </select>
                    </div>
                  </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Comisión agencia</label>
                    <input class="form-control" name="fs[comision_agencia]" id="input-comision-agencia" readonly="" />
                  </div>
                </div>
              </div>


              <div class="row">
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Comisión asesor</label>
                    <input class="form-control" name="fs[comision_asesor]" id="input-comision-asesor" readonly/>
                  </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                      <label>Tipo de seguro</label>
                      <select class="form-control" name="fs[compania_seg]">
                        <option value="Anual">Anual</option>
                        <option value="Financiado">Financiado</option>
                        <option value="Anual contado">Anual contado</option>
                        <option value="Todo contado">Todo contado</option>
                        <option value="Todo financiado">Todo financiado</option>
                      </select>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                      <label>Compañia de seguro</label>
                      <select class="form-control" name="fs[compania_seg]">
                        <option value="Zurich">Zurich</option>
                        <option value="Qualitas">Qualitas</option>
                        <option value="Aba">Aba</option>
                        <option value="Axa">Axa</option>
                        <option value="HDI">HDI</option>
                      </select>
                    </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>No. de poliza</label>
                    <input class="form-control" name="fs[no_poliza]" />
                  </div>
                </div>
              </div>



              <div class="row">
                 <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Inicio de vigencia</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[inicio_vigencia]">
                        </div>
                    </div>
                  </div>
                 <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Vencimiento anual</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[vencimiento_anual]">
                        </div>
                    </div>
                  </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Prima total</label>
                    <input id="prima-total" class="form-control"  name="fs[prima_total]"/>
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>IVA</label>
                    <input id="iva" class="form-control"  name="fs[iva]"  readonly="" />
                  </div>
                </div>
              </div>


              <div class="row">
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Emisión de póliza</label>
                    <input id="emision-poliza" class="form-control"  val="0.00" name="fs[emision_poliza]"/>
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Prima neta</label>
                    <input id="prima-neta" class="form-control"  name="fs[prima_neta]" readonly=""/>
                  </div>
                </div>

                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Udi agencia</label>
                    <input id="udi-agencia" class="form-control"  name="fs[udi_agencia]"  readonly="" />
                  </div>
                </div>

                <div class="col-sm-3">
                  <div class="form-group">
                    <label>comision asesor</label>
                    <input id="comision-asesor-prima" class="form-control" name="fs[comision_asesor_prima]"  readonly="" />
                  </div>
                </div>

              </div>


              <div class="row">

                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>% UDI</label>
                      <select class="form-control" name="fs[udi]">
                        <option value="ABA VESA 26%">ABA VESA 26%</option>
                        <option value="QUALITAS AMDF 26%">QUALITAS AMDF 26%</option>
                        <option value="QUALITAS PLASENCIA 25%">QUALITAS PLASENCIA 25%</option>
                        <option value="QUALITAS EMPLEADO 6%">QUALITAS EMPLEADO 6%</option>
                        <option value="FORD INSURE ZURICH 24%">FORD INSURE ZURICH 24%</option>
                        <option value="ISTRA 20%">ISTRA 20%</option>
                        <option value="QUALITAS">QUALITAS</option>
                        <option value="ABA">ABA</option>
                        <option value="AFIRME">AFIRME</option>
                        <option value="AIG">AIG</option>
                        <option value="AXA">AXA</option>
                        <option value="GNP">GNP</option>
                        <option value="HDI">HDI</option>
                        <option value="SURA">SURA</option>
                        <option value="MAPFRE">MAPFRE</option>
                        <option value="ZURICH">ZURICH</option>
                        <option value="SANTANA">SANTANA</option>
                        <option value="QUALITAS 15% Y 20%">QUALITAS 15% Y 20%</option>
                        <option value="GNP 20%">GNP 20%</option>
                        <option value="HDI 20%">HDI 20%</option>
                        <option value="Otros">Otros</option>
                      </select>
                    </div>
                  </div>

              </div>


            </div>
        </div>
    </div>
  </div>
</div>



<!-- FIN DEL CUARTO FORMULARIO -->

<div class="row">
  <div class="col-sm-12">
          <div>
            <button class="btn btn-sm btn-primary text-center m-t-n-xs" type="submit"><strong>Enviar </strong></button>
          </div>

    </div>
  </div>
</form>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h1 class="modal-title">Bitacora de negocios</h1>
      </div>
      <div class="modal-body">
            <h3>Lista de registros</h3>




   <?php


    function build_table($array){
    // start table
    $html = '<table id="my-final-table">';
    // header row
    $html .= '<thead>';
    foreach($array[0] as $key=>$value){

            $html .= '<th>' . htmlspecialchars(strtolower($key)) . '</th>';
        }
    $html .= '</thead>';
    $html .= '<tbody>';
    $html .= '</tbody>';

    // data rows
  /*  foreach( $array as $key=>$value){
        $html .= '<tr>';
        foreach($value as $key2=>$value2){
            $html .= '<td>' . htmlspecialchars($value2) . '</td>';
        }
        $html .= '</tr>';
    }*/

    // finish table and return it

    $html .= '</table>';
    echo($html);
}



echo build_table($nada);




?>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
      </div>
    </div>

  </div>
</div>
