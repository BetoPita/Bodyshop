
<link href="<?php echo base_url();?>statics/css/tema/css/plugins/clockpicker/clockpicker.css" rel="stylesheet">

<link href="<?php echo base_url();?>statics/css/tema/css/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet">
<link href="<?php echo base_url();?>statics/css/bootstrap/css/bootstrap-switch.css" rel="stylesheet">
<!-- Color picker -->
<script src="<?php echo base_url();?>statics/css/tema/js/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>

<!-- Clock picker -->
<script src="<?php echo base_url();?>statics/css/tema/js/plugins/clockpicker/clockpicker.js"></script>

<script src="<?php echo base_url();?>statics/css/tema/js/plugins/daterangepicker/daterangepicker.js"></script>

 <script src="<?php echo base_url();?>statics/css/tema/js/plugins/datapicker/bootstrap-datepicker.js"></script>

 <script src="<?php echo base_url();?>statics/css/bootstrap/js/bootstrap-switch.js"></script>

 <script src="<?php echo base_url();?>statics/js/custom/bootbox.min.js"></script>

<script src="<?php echo base_url();?>statics/js/custom/general.js"></script>
<script>

window.onload = function() {
    if(!window.location.hash) {
        window.location = window.location + '#loaded';
        window.location.reload();
    }
}

$(document).ready(function(){

 // $(".form-control").attr('required','required');
 mensaje="<?php echo $this->session->flashdata('msg') ?>";

   if(mensaje!=''){
    ExitoCustom(mensaje,2);
   }
records =  <?php Print($json_registros); ?>;  


for(var i = 0; i < records.length; i++) {
    var obj = records[i];

    //obj.push({"nuevo_campo": "valor"});
    //obj.editar = "<a class='edit-link' href='#'>Editar</a>";

        obj.editar = '<a class="edit-button" href="#"> <svg fill="#1ab394" height="18" viewBox="0 0 24 24" width="18" xmlns="http://www.w3.org/2000/svg"> <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/> <path d="M0 0h24v24H0z" fill="none"/></svg></a> <a class="print-button" href="#"><svg fill="#1ab394" height="18" viewBox="0 0 24 24" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/><path d="M0 0h24v24H0z" fill="none"/></svg></a>';

   
}
   




  $('#my-final-table').dynatable({
          features: {
                    pushState: false,
                    paginate: true,
                    sort: false,
                    recordCount: true
                },
   table: {
        defaultColumnIdStyle: 'camelCase'
        
    },
  dataset: {
    records: records
  }

   }).bind('dynatable:afterUpdate', processingComplete());


$("#my-final-table").dynatable().on("dynatable:afterProcess", dyntablePagination());  
    function dyntablePagination()  {
         $(document).on('click', '.dynatable-page-link', function() {
             setTimeout(function(){
                $(".edit-button").click(function() {
                  var td =  $(this).parent();
                  var tr= $(td).parent();
                  var id = $(tr).children(':first-child').text();
                   create(id);
                });
                 
                $(".print-button").click(function() {
                     var td =  $(this).parent(tr);
                     var tr= $(td).parent();
                     printRegister(tr);
                   
                });

            $("#my-final-table td:not(:last-child)").dblclick(function(){
            
             var tr= $(this).parent();
             var id = $(tr).children(':first-child').text();
             create(id);
          });


             },0);
         });

         $( "#my-final-table" ).wrap(function() {
             return "<div id='" + "scroll-div" + "'></div>";
         });

         var mx = 0;

$("#scroll-div").on({
  mousemove: function(e) {
    var mx2 = e.pageX - this.offsetLeft;
    if(mx) this.scrollLeft = this.sx + mx - mx2;
  },
  mousedown: function(e) {
    this.sx = this.scrollLeft;
    mx = e.pageX - this.offsetLeft;
  }
});

$(document).on("mouseup", function(){
  mx = 0;
});

$("#my-final-table td:not(:last-child)").dblclick(function(){
            
             var tr= $(this).parent();
             var id = $(tr).children(':first-child').text();
             create(id);
});

/*$("#my-final-table td:not(:last-child)").mouseup(function(){

  clearTimeout(pressTimer);
  // Clear timeout
  return false;
}).mousedown(function(){
  // Set timeout
  pressTimer = window.setTimeout(function() { 
     
          var $this = $(this);
          var tr= $this.parent();
            $(tr).find('td').each (function() {
               alert($(this).text());
            });
            //printRegister(tr);



  },1000);
  return false; 
});*/



     }


$("#dynatable-query-search-my-final-table").on('keyup', function (e) {
    if (e.keyCode == 13) {

            $(".edit-button").click(function() {
             var td =  $(this).parent();
             var tr= $(td).parent();
             var id = $(tr).children(':first-child').text();
             create(id);
   
            });

            $(".print-button").click(function() {
              var td =  $(this).parent();
              var tr= $(td).parent();
              printRegister(tr);

            });

       
    }






});









  $(".edit-button").click(function() {
             var td =  $(this).parent();
             var tr= $(td).parent();
             var id = $(tr).children(':first-child').text();
             create(id);

            
            
    });

  $(".print-button").click(function() {
    var td =  $(this).parent();
    var tr= $(td).parent();
    printRegister(tr);

  });

  $('#select-financiera').append(new Option('OTROS', 'OTROS', false, false));

$( "#select-financiera" ).change(function() {
  var val = $( "#select-financiera option:selected" ).val();
    if(val=="OTROS"){
     
      var financiera = prompt("Ingresa el nombre de la financiera a agregar");
      if(financiera != null)
         $("#select-financiera option:last").before("<option value='"+financiera+"' selected='selected' >"+financiera+"</option>");
       else
        $('#select-financiera option:first-child').attr("selected", "selected");

   }
  });
  




});



function processingComplete (){
        $(".edit-button").click(function() {
             var td =  $(this).parent();
             var tr= $(td).parent();
             var id = $(tr).children(':first-child').text();
            
             create(id);

            
         });

         $(".print-button").click(function() {
             var td =  $(this).parent();
             var tr= $(td).parent();
            printRegister(tr);
               
          });

  
      

}

function printRegister(tr){

  var data = [];

 
  $(tr).find('td').each (function() {

    var celda = $(this).text();
    
    if(celda.length >= 40){
      var array;
      array = celda.match(/.{1,40}/g);
      celda="";
      for (var i = 0; i <= array.length - 1; i++) {
          celda += array[i] +  "\r\n";
      }

    }

    
    data.push(celda);

  });

 console.log(data);

  /*  var celda = data[12];
    if(celda.length >= 35){

      console.log(celda.match(/.{1,35}/g));
    }*/
    

var doc = new jsPDF();
doc.text(50, 10, 'FORD PLASCENCIA - Seguros y Financiamiento');
doc.text(20, 30, 'Asesor: ' + data[1]);
doc.text(20, 40, 'Nombre del Cliente: ' + data[2]);
doc.text(20, 50, 'Tel. Casa: ' + data[3]);
doc.text(20, 60, 'Movil: ' + data[4]);
doc.text(20, 70, 'Tel. Oficina: ' + data[5]);
doc.text(20, 80, 'Correo electrónico: ' + data[6]);
doc.text(20, 90, 'Mes: ' + data[7]);
doc.text(20, 100, 'Fecha de Recepcion Docs: ' + data[8]);
doc.text(20, 110, 'Hora de Recepcion Docs: ' + data[9]);
doc.text(20, 120, 'Hora de Inicio de Análisis: ' + data[10]);
doc.text(20, 130, 'Comentarios: ' + data[11]);
doc.text(20, 150, 'Modelo: ' + data[12]);
doc.text(20, 170, 'Financiera: ' + data[13]);
doc.text(20, 180, 'Estatus: ' + data[14]);
doc.text(20, 190, 'Propuesta folio: ' + data[15]);
doc.text(20, 200, 'Fecha de condicionamiento: ' + data[16]);
doc.text(20, 210, 'Hora de condicionamiento: ' + data[17]);
doc.text(20, 220, 'Fecha de cumplimiento: ' + data[18]);
doc.text(20, 230, 'Hora de cumplimiento: ' + data[19]);
doc.text(20, 240, 'Fecha de aprobación: ' + data[20]);
doc.text(20, 250, 'Hora de aprobación: ' + data[21]);
doc.text(20, 260, 'Fecha de contrato: ' + data[22]);
doc.text(20, 270, 'Hora de contrato: ' + data[23]);

doc.addPage();
doc.text(20, 10, 'Estatus plan-piso: ' + data[24]);
doc.text(20, 20, 'Fecha de compra: ' + data[25]);
doc.text(20, 30, 'Hora de compra: ' + data[26]);
doc.text(20, 40, 'Comentarios contrato-compra: ' + data[27]);
doc.text(20, 50, 'Nombre del plan: ' + data[28]);
doc.text(20, 60, 'Bono fc: ' + data[29]);
doc.text(20, 70, 'Plazo: ' + data[30]);
doc.text(20, 80, 'Precio de unidad: ' + data[31]);
doc.text(20, 90, 'Enganche: ' + data[32]);
doc.text(20, 100, 'Monto a financiar: ' + data[33]);
doc.text(20, 110, 'Comisión: ' + data[34]);
doc.text(20, 120, 'Comisión de Agencia: ' + data[35]);
doc.text(20, 130, 'Comisión de Asesor: ' + data[36]);
doc.text(20, 140, 'Tipo de seguro ' + data[37]);
doc.text(20, 150, 'Compañia de seguro: ' + data[38]);
doc.text(20, 160, 'No. Poliza: ' + data[39]);
doc.text(20, 170, 'Inicio de vigencia: ' + data[40]);
doc.text(20, 180, 'Vencimiento anual: ' + data[41]);
doc.text(20, 190, 'Prima total: ' + data[42]);
doc.text(20, 200, 'IVA: ' + data[43]);
doc.text(20, 210, 'Emision: ' + data[44]);
doc.text(20, 220, 'Prima neta: ' + data[45]);
doc.text(20, 230, 'UDI Agencia: ' + data[46]);
doc.text(20, 240, 'Comision asesor (Prima): ' + data[47]);
doc.text(20, 250, 'UDI : ' + data[48]);
doc.text(20, 260, 'HTML : ' + "un parrafo con un \r\n salto de linea<" + "<p>" + data[48]+ "</p>");

var blob = doc.output("blob");
window.open(URL.createObjectURL(blob));



//doc.output('Bitacora_de_facturacion_' + data[1]+'_.pdf');
}





 function create(id){

  
          $.ajax({
            url:"<?php echo base_url(); ?>index.php/bitacora_negocios/get_bitacora_negocios ", 
            type: "post", //request type,
            dataType: 'json',
           data: {id: id},
            success:function(result){

             setValues(result);
             console.log(result);
             
           },
            error: function(xhr) {
             alert ("Oopsie: " + xhr.statusText);
             }
         });
     

}


function setValues(result){




  $("#input-precio-unidad").maskMoney();
  $("#input-enganche").maskMoney();
  $("#prima-total").maskMoney();
  $("#emision-poliza").maskMoney();


  $("input[name*='fecha_aprobacion']" ).mask('00/00/0000');
  $("input[name*='fecha_condicionamiento']" ).mask('00/00/0000');
  $("input[name*='fecha_contrato']" ).mask('00/00/0000');
  $("input[name*='fecha_compra']" ).mask('00/00/0000');
  $("input[name*='fecha_cumplimiento']" ).mask('00/00/0000');
  $("input[name*='fecha_recepcion_docs']" ).mask('00/00/0000');
  $("input[name*='vencimiento_anual']" ).mask('00/00/0000');
  $("input[name*='inicio_vigencia']" ).mask('00/00/0000');
  $("input[name*='emision']" ).mask('00/00/0000');

  $("input[name*='hora_condicion']" ).mask('00:00');
  $("input[name*='hora_cumplimiento']" ).mask('00:00');
  $("input[name*='hora_contrato']" ).mask('00:00');
  $("input[name*='hora_compra']" ).mask('00:00');
  $("input[name*='hora_aprobacion']" ).mask('00:00');
  $("input[name*='hora_recepcion_docs']" ).mask('00:00');
  $("input[name*='hora_inicio_analisis']" ).mask('00:00');

   var id = result.registro[0].id

   $("#select-asesor option:contains(" + result.registro[0].asesor + ")").attr('selected', true);
   $("input[name*='nombre_cliente']" ).val(result.registro[0].nombre_cliente);
   $("input[name*='tel_casa']" ).val(result.registro[0].tel_casa);
   $("input[name*='movil']" ).val(result.registro[0].movil);
   $("input[name*='tel_oficina']" ).val(result.registro[0].tel_oficina);
   $("input[name*='correo_electronico']" ).val(result.registro[0].correo_electronico);

   $("#select-mes option:contains(" + result.registro[0].mes + ")").attr('selected', true);
   $("input[name*='fecha_recepcion_docs']" ).val(result.registro[0].fecha_recepcion_docs);
   $("input[name*='hora_recepcion_docs']" ).val(result.registro[0].hora_recepcion_docs);
   $("input[name*='hora_inicio_analisis']" ).val(result.registro[0].hora_inicio_analisis);
   $("input[name*='comentarios']" ).val(result.registro[0].comentarios);
   $("#select-modelo option:contains(" + result.registro[0].modelo + ")").attr('selected', true);
   $("#select-financiera option:contains(" + result.registro[0].financiera + ")").attr('selected', true);
   $("#select-status option:contains(" + result.registro[0].status + ")").attr('selected', true);
   $("input[name*='propuesta_folio_contrato']" ).val(result.registro[0].propuesta_folio_contrato);

    $("input[name*='fecha_condicionamiento']" ).val(result.registro[0].fecha_condicionamiento);
    $("input[name*='hora_condicion']" ).val(result.registro[0].hora_condicion);
    $("input[name*='fecha_cumplimiento']" ).val(result.registro[0].fecha_cumplimiento);
    $("input[name*='hora_cumplimiento']" ).val(result.registro[0].hora_cumplimiento);
    $("input[name*='fecha_aprobacion']" ).val(result.registro[0].fecha_aprobacion);
    $("input[name*='hora_aprobacion']" ).val(result.registro[0].hora_aprobacion);
    $("input[name*='fecha_contrato']" ).val(result.registro[0].hora_contrato);
    $("input[name*='hora_contrato']" ).val(result.registro[0].hora_contrato);
    $("#select-status-plan option:contains(" + result.registro[0].estatus_plan_piso + ")").attr('selected', true);
    $("input[name*='fecha_compra']" ).val(result.registro[0].hora_compra);
    $("input[name*='hora_compra']" ).val(result.registro[0].hora_compra);
    $("input[name*='comentarios_contrato_compra']" ).val(result.registro[0].comentarios_contrato_compra);

    $("input[name*='nombre_plan']" ).val(result.registro[0].nombre_plan);
    $("input[name*='bono_fc']" ).val(result.registro[0].bono_fc);
    $("input[name*='plazo']" ).val(result.registro[0].plazo);
    $("input[name*='precio_unidad']" ).val(result.registro[0].precio_unidad);
    $("input[name*='enganche']" ).val(result.registro[0].enganche);
    $("input[name*='monto_financiar']" ).val(result.registro[0].monto_financiar);
    $("#porcentaje-comision option:contains(" + result.registro[0].comision + ")").attr('selected', true);
    $("input[name*='comision_agencia']" ).val(result.registro[0].comision_agencia);
    $("input[name*='comision_asesor']" ).val(result.registro[0].comision_asesor);
    $("#select-tipo-seguro option:contains(" + result.registro[0].tipo_seguro + ")").attr('selected', true);
    $("#select-compania-seguro option:contains(" + result.registro[0].compania_seg + ")").attr('selected', true);
    $("input[name*='no_poliza']" ).val(result.registro[0].no_poliza);
    $("input[name*='inicio_vigencia']" ).val(result.registro[0].inicio_vigencia);
    $("input[name*='vencimiento_anual']" ).val(result.registro[0].vencimiento_anual);
    $("input[name*='prima_total']" ).val(result.registro[0].prima_total);
    $("input[name*='iva']" ).val(result.registro[0].iva);
    $("input[name*='emision_poliza']" ).val(result.registro[0].emision_poliza);
    $("input[name*='prima_neta']" ).val(result.registro[0].prima_neta);
    $("#select-udi option:contains(" + result.registro[0].udi + ")").attr('selected', true);
    $("input[name*='udi_agencia']" ).val(result.registro[0].udi_agencia);
    $("input[name*='comision_asesor_prima']" ).val(result.registro[0].comision_asesor_prima);
    $("#finalizado" ).val(result.registro[0].finalizado);

    
    
    if(result.registro[0].finalizado==1){
      var state = true;
    }else{
      var state = false;
    }
    $("[name='my-checkbox']").bootstrapSwitch({
      onColor:"success",
      offColor:'danger',
      onText:"Si",
      offText: "No",
      state:state
    });

    $("#input-comision-agencia").on("change paste keyup", function() {
     var val = $(this).val(); 
     var comision = val * 0.30;
     $("#input-comision-asesor").val(comision);
  });

$("#input-precio-unidad").on("change paste keyup", function() {
   var financiar;
   var precioUnidad = $(this).val(); 

  precioUnidad = precioUnidad.replace(",","");

   var enganche = $.trim($("#input-enganche").val());
   if(enganche.length == 0)
    {
       enganche = 0;
       $("#input-monto-financiar").val(precioUnidad);
    }

    else{
      
      enganche = enganche.replace(",",""); 

      financiar = precioUnidad - enganche;
    }
    $("#input-monto-financiar").val(financiar);

        var monto= $("#input-monto-financiar").val() 
    var porcentaje = $( "#porcentaje-comision option:selected" ).text();
        porcentaje = porcentaje.replace("%","");
        porcentaje = porcentaje / 100;

     comAgencia = (monto * porcentaje);
      alert(comAgencia);
     $("#input-comision-agencia").val(comAgencia);
  

     var comAsesor = comAgencia * 0.3;

     $("#input-comision-asesor").val(comAsesor);
     
});

$("#input-enganche").on("change paste keyup", function() {
   var enganche = $(this).val(); 
   var precioUnidad = $("#input-precio-unidad").val(); 

   enganche = enganche.replace(",","");
   precioUnidad = precioUnidad.replace(",","");

   var financiar = precioUnidad - enganche
   
   $("#input-monto-financiar").val(financiar);

   var monto = $("#input-monto-financiar").val();
   var porcentaje = $( "#porcentaje-comision option:selected" ).text();
    porcentaje = porcentaje.replace("%","");
    porcentaje = porcentaje / 100;
    var comisionAgencia = 1*(monto * porcentaje)
    $("#input-comision-agencia").val(comisionAgencia);
    var comisionAsesor = comisionAgencia * 0.3;
    $("#input-comision-asesor").val(comisionAsesor);


});

$("#porcentaje-comision").change(function () {
        //var end = this.value;
        var monto = $("#input-monto-financiar").val();
        var porcentaje = $( "#porcentaje-comision option:selected" ).text();
        porcentaje = porcentaje.replace("%","");
        porcentaje = porcentaje / 100;
        var comisionAgencia = 1*(monto * porcentaje)
        $("#input-comision-agencia").val(comisionAgencia);
        var comisionAsesor = comisionAgencia * 0.3;
        $("#input-comision-asesor").val(comisionAsesor);
  });

$("#prima-total").on("change paste keyup", function() {
   var primaTotal = $(this).val(); 
   primaTotal = primaTotal.replace(",","");
   var iva = $("#iva").val();
   iva = primaTotal * 0.16;
   $("#iva").val(iva);

   var emisionPoliza =  $("#emision-poliza").val();
   emisionPoliza = emisionPoliza.replace(",","");
   var primaNeta = primaTotal - iva - emisionPoliza;
   $("#prima-neta").val(primaNeta);

   var comisionAgencia = primaNeta * 0.24;
   $("#udi-agencia").val(comisionAgencia);

   var comisionAsesor = comisionAgencia * 0.30;
   $("#comision-asesor-prima").val(comisionAsesor);
   


});

$("#emision-poliza").on("change paste keyup", function() {
   var emisionPoliza = $(this).val();
   var primaTotal = $("#prima-total").val(); 
   var iva = $("#iva").val();

   primaTotal = primaTotal.replace(",","");
   emisionPoliza = emisionPoliza.replace(",","");
   iva = iva.replace(",","");

   var primaNeta = primaTotal - emisionPoliza - iva;
   $("#prima-neta").val(primaNeta);

   var comisionAgencia = primaNeta * 0.24;
   $("#udi-agencia").val(comisionAgencia);

   var comisionAsesor = comisionAgencia * 0.30;
   $("#comision-asesor-prima").val(comisionAsesor);



   

});






   
   
  
   $("#input-id").val(id);

   $("#myModal").modal('show');
  $('.clockpicker').clockpicker();

   $('.datepicker').datepicker({
     format: 'dd/mm/yyyy',
   
   });
  
  
  $("[name='my-checkbox']").on('switchChange.bootstrapSwitch', function(event, state) {
    if(state){// true | false
      $("#finalizado").val(1);
    }else{
       $("#finalizado").val(0);
    }
    
  });  
      

}
</script>

 <style type="text/css">

 #scroll-div {
  overflow-x: scroll;
  overflow-y: scroll;
  width: 90%;
  height: 500px;
  margin:0 auto;
  -webkit-touch-callout: none;
  -webkit-user-select: none;  
  -moz-user-select: none;   
  -ms-user-select: none;     
  user-select: none; 
}

 #scroll-div{


 }

 
  .clockpicker-popover {
    z-index: 999999;
}

  #table-wrapper {
 
   /* overflow-y: scroll;*/
}

 #my-final-table{
    

 }



#my-final-table th {
  background: #006a72;
}
#my-final-table th a {
  color: #fff;
}
#my-final-table th a:hover {
  color: #fff;
  text-decoration: underline;
}

#my-final-table , #my-final-table th, #my-final-table td {
   border: 1px solid #ddd;
   text-align: center;
}

#my-final-table {


  padding-right: 30px;
}

#my-final-table th, #my-final-table td{

  padding-right: 15px;
  padding-left: 15px;
}

.dynatable-head{
   color: #ffffff;
}

.dynatable-search {
  float: right;
  margin-bottom: 10px;
}

.dynatable-pagination-links {
  float: right;
}

.dynatable-record-count {
  display: block;
  padding: 5px 0;
}

.dynatable-pagination-links span,
.dynatable-pagination-links li {
  display: inline-block;
}

.dynatable-page-link,
.dynatable-page-break {
  display: block;
  padding: 5px 7px;
}

.dynatable-page-link {
  cursor: pointer;
}

.dynatable-active-page,
.dynatable-disabled-page {
  cursor: text;
}
.dynatable-active-page:hover,
.dynatable-disabled-page:hover {
  text-decoration: none;
}

.dynatable-active-page {
  background: #006a72;
  border-radius: 5px;
  color: #fff;
}
.dynatable-active-page:hover {
  color: #fff;
}
.dynatable-disabled-page,
.dynatable-disabled-page:hover {
  background: none;
  color: #999;
}


/* Important part */
.modal-dialog{
    overflow-y: initial !important

}
.modal-body{
    height: 250px;
    overflow-y: auto;
}

@media (min-width: 768px){
 .modal-dialog {
    width: 1200px;
    margin: 30px auto;
  }
}

  </style>


 <?php
    function build_table($registros){

    $html = '<h1 class="modal-title">Seguros y financiamiento -  Búsquedas</h1>';
    $html .= '<table id="my-final-table">';
    // header row
    $html .= '<thead>';
    foreach($registros[0] as $key=>$value){
        
            $html .= '<th>' . htmlspecialchars(strtolower($key)) . '</th>';
        }
    $html .= '<th>' . "editar" . '</th>';
    $html .= '</thead>';
    $html .= '<tbody>';
    $html .= '</tbody>';
    $html .= '</table>';
    echo("<div id='table-wrapper'>".$html."</div>");
}
echo build_table($registros);

?>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h1 class="modal-title">Seguros y financiamiento -  Editar registro</h1>
      </div>
      <div class="modal-body">
      <div id="formulario-wrapper">

      <h3>Seguros y financiamiento</h3>
<div class="row">
  <div class="col-sm-12">
    <div class="modal-dialog1">
        <div class="modal-content1">
            <div class="modal-body1">
             <div class="row">
               <div class="col-sm-8">
                  <h2>Datos de contacto para el cliente</h2>
               </div>
               <div class="col-sm-2 pull-right form-group">
                      <label>¿Finalizado?</label>
                      <input type="checkbox" id="bs_finalizado" name="my-checkbox" class="bootstrap-switch-success">
                  </div>
             </div>

              <form role="form" action="<?php echo base_url();?>index.php/bitacora_negocios/busquedas" method="post">
              <input type="hidden" id="finalizado" name="fs[finalizado]" value="">
              <div class="row">

                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Asesor</label>
                    <select id="select-asesor" class="form-control" name="fs[asesor]">
                     <?php
                        $json_obj = json_decode( $json_asesores, true );
                          foreach( $json_obj as $key => $value){
                            echo "<option value='".$value["nombre"]."'> ".$value["nombre"]."</option>";
                          }
                      ?>
                   
                    </select>
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Nombre del ciente</label>
                    <input class="form-control" name="fs[nombre_cliente]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Tel casa</label>
                    <input class="form-control" name="fs[tel_casa]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Movil</label>
                    <input class="form-control" name="fs[movil]" />
                  </div>
                </div>
              </div>




              <div class="row">

                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Tel oficina</label>
                    <input class="form-control" name="fs[tel_oficina]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Correo electrónico</label>
                    <input class="form-control" name="fs[correo_electronico]" />
                  </div>

                </div>
                <div class="col-sm-3">

                </div>
              </div>

            </div>
        </div>
    </div>
  </div>
</div>



  <!-- INICIO SEGUNDO FORMULARIO -->


   

  <div class="row">
    <div class="col-sm-12">
      <div class="modal-dialog1">
          <div class="modal-content1">
              <div class="modal-body1">
                <h2>Inicio de medición del tiempo</h2>
                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Mes</label>
                      <select id="select-mes" class="form-control" name="fs[mes]">
                        <option value="Enero">Enero</option>
                        <option value="Febrero">Febrero</option>
                        <option value="Marzo">Marzo</option>
                        <option value="Abril">Abril</option>
                        <option value="Mayo">Mayo</option>
                        <option value="Junio">Junio</option>
                        <option value="Julio">Julio</option>
                        <option value="Agosto">Agosto</option>
                        <option value="Septiembre">Septiembre</option>
                        <option value="Octubre">Octubre</option>
                        <option value="Noviembre">Noviembre</option>
                        <option value="Diciembre">Diciembre</option>
                      </select>

                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de Recepcion Docs</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_recepcion_docs]">
                        </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de Recepción Docs</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_recepcion_docs]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de inicio del análisis</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_inicio_analisis]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                </div>




                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Comentarios</label>
                      <input class="form-control" name="fs[comentarios]" />
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Modelo</label>
                      <select id="select-modelo" class="form-control" name="fs[modelo]">
                      <?php
                        $json_obj = json_decode( $json_modelos, true );
                          foreach( $json_obj as $key => $value){
                            echo "<option value='".$value["modelo"]."'> ".$value["modelo"]."</option>";
                          }
                      ?>
                      </select>
                    </div>
                  </div>

                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Financiera</label>
                      <select id="select-financiera" class="form-control" name="fs[financiera]">
                        <?php
                           $json_obj = json_decode( $json_financieras, true );
                          foreach( $json_obj as $key => $value){
                            echo "<option value='".$value["nombre"]."'> ".$value["nombre"]."</option>";
                          }
                      ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Estatus</label>
                      <select id="select-status" class="form-control" name="fs[status]">
                        <option value="Recibido">Recibido</option>
                        <option value="Análisis">Análisis</option>
                        <option value="Condición">Condición</option>
                        <option value="En Reconsideración">En Reconsideración</option>
                        <option value="Aprobado">Aprobado</option>
                        <option value="Contrato Generado">Contrato Generado</option>
                        <option value="Validación Enganche">Validación Enganche</option>
                        <option value="Pago Plan piso">Pago Plan piso</option>
                        <option value="Envio Compra">Envio Compra</option>
                        <option value="Rechazo">Rechazo</option>
                        <option value="Comprada">Comprada</option>
                        <option value="Canceló">Canceló</option>
                        <option value="Refacturación">Refacturación</option>
                        <option value="Desembolso">Desembolso</option>
                      </select>
                    </div>

                  </div>
                </div>


                <div class="row">

                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Propuesta/Folio/contrato</label>
                      <input class="form-control" name="fs[propuesta_folio_contrato]" />
                    </div>
                  </div>
          
           
                </div>
              </div>
          </div>
      </div>
    </div>
  </div>

  <!-- FIN DE SEGUNDO FORMULARIO -- >


<!-- INICIO TERCER FORMULARIO -->

  <div class="row">
    <div class="col-sm-12">
      <div class="modal-dialog1">
          <div class="modal-content1">
              <div class="modal-body1">
                <h2>Medición del tiempo</h2>
                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de condicionamiento</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_condicionamiento]">
                        </div>
                    </div>
                  </div>
                   <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de condicionamiento</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_condicion]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de cumplimiento</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_cumplimiento]">
                        </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de cumplimiento</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_cumplimiento]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                </div>




                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de aprobación</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_aprobacion]">
                        </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de aprobación</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_aprobacion]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de contrato</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_contrato]">
                        </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de contrato</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_contrato]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                </div>



                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Estatus plan piso</label>
                      <select id="select-status-plan" class="form-control" name="fs[estatus_plan_piso]"> 
                        <option value="Unidad propia">Unidad propia</option>
                        <option value="Intercambio">Intercambio</option>
                        <option value="Se debe">Se debe</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Fecha de compra</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[fecha_compra]">
                        </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Hora de compra</label>
                      <div class="input-group clockpicker" data-autoclose="true">
                          <input id="hora-entrega" type="text" class="form-control" placeholder="hh:mm" value="" name="fs[hora_compra]">
                          <span class="input-group-addon">
                              <span class="fa fa-clock-o"></span>
                          </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>Comentarios contrato/compra</label>
                      <input class="form-control" name="fs[comentarios_contrato_compra]" />
                    </div>
                  </div>
                </div>


              </div>
          </div>
      </div>
    </div>
  </div>




<!-- FIN TERCER FORMULARIO -->

<!-- INICIO DEL CUARTO FORMULARIO -->

  <div class="row">
  <div class="col-sm-12">
    <div class="modal-dialog1">
        <div class="modal-content1">
            <div class="modal-body1">
              <h2>Administración de utilidad</h2>
              <div class="row">
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Nombre del plan</label>
                    <input class="form-control" name="fs[nombre_plan]" />
                  </div>
                </div>
           
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Bono FC</label>
                    <input class="form-control" name="fs[bono_fc]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Plazo</label>
                    <input class="form-control" name="fs[plazo]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Precio unidad</label>
                    <input id="input-precio-unidad" class="form-control" name="fs[precio_unidad]" />
                  </div>
                </div>
              </div>


              <div class="row">
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Enganche</label>
                    <input id="input-enganche" class="form-control" name="fs[enganche]" />
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Monto a financiar</label>
                    <input id="input-monto-financiar" class="form-control" name="fs[monto_financiar]" readonly/>
                  </div>
                </div>
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>% Comision</label>
                      <select id="porcentaje-comision" class="form-control" name="fs[comision]"> 
                        <option value="0%">0%</option>
                        <option value="0.5%">0.5%</option>
                        <option value="1.0%">1.0%</option>
                        <option value="1.5%">1.5%</option>
                        <option value="2%">2%</option>
                        <option value="3%">3%</option>
                        <option value="4%">4%</option>
                        <option value="5%">5%</option>
                      </select>
                    </div>
                  </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Comisión agencia</label>
                    <input class="form-control" name="fs[comision_agencia]" id="input-comision-agencia" readonly="" />
                  </div>
                </div>
              </div>


              <div class="row">
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Comisión asesor</label>
                    <input class="form-control" name="fs[comision_asesor]" id="input-comision-asesor" readonly/>
                  </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                      <label>Tipo de seguro</label>
                       <select id="select-tipo-seguro"class="form-control" name="fs[compania_seg]">
                          <option value="Anual">Anual</option>
                          <option value="Financiado">Financiado</option>
                          <option value="Anual contado">Anual contado</option>
                          <option value="Todo contado">Todo contado</option>
                          <option value="Todo financiado">Todo financiado</option>
                      </select>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                      <label>Compañia de seguro</label>
                      <select id="select-compania-seguro" class="form-control" name="fs[compania_seg]">
                        <option value="Zurich">Zurich</option>
                        <option value="Qualitas">Qualitas</option>
                        <option value="Aba">Aba</option>
                        <option value="Axa">Axa</option>
                        <option value="HDI">HDI</option>
                      </select>
                    </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>No. de poliza</label>
                    <input class="form-control" name="fs[no_poliza]" />
                  </div>
                </div>
              </div>



              <div class="row">
                 <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Inicio de vigencia</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[inicio_vigencia]">
                        </div>
                    </div>
                  </div>
                 <div class="col-sm-3">
                    <div class="form-group" id="data_1">
                        <label class="font-noraml">Vencimiento anual</label>
                        <div class="input-group ">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
                            <input type="text" class="form-control datepicker" value="" name="fs[vencimiento_anual]">
                        </div>
                    </div>
                  </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Prima total</label>
                    <input id="prima-total" class="form-control"  name="fs[prima_total]"/>
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>IVA</label>
                    <input id="iva" class="form-control"  name="fs[iva]" readonly="" />
                  </div>
                </div>
              </div>

             <div class="row">
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Emisión de póliza</label>
                    <input id="emision-poliza" class="form-control"  val="0.00" name="fs[emision_poliza]"/>
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Prima neta</label>
                    <input id="prima-neta" class="form-control"  name="fs[prima_neta]" readonly=""/>
                  </div>
                </div>

                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Udi agencia</label>
                    <input id="udi-agencia" class="form-control"  name="fs[udi_agencia]"  readonly="" />
                  </div>
                </div>

                <div class="col-sm-3">
                  <div class="form-group">
                    <label>comision asesor</label>
                    <input id="comision-asesor-prima" class="form-control" name="fs[comision_asesor_prima]"  readonly="" />
                  </div>
                </div>

              </div>


               <div class="row">
  
                  <div class="col-sm-3">
                    <div class="form-group">
                      <label>% UDI</label>
                      <select class="form-control" name="fs[udi]"> 
                        <option value="ABA VESA 26%">ABA VESA 26%</option>
                        <option value="QUALITAS AMDF 26%">QUALITAS AMDF 26%</option>
                        <option value="QUALITAS PLASENCIA 25%">QUALITAS PLASENCIA 25%</option>
                        <option value="QUALITAS EMPLEADO 6%">QUALITAS EMPLEADO 6%</option>
                        <option value="FORD INSURE ZURICH 24%">FORD INSURE ZURICH 24%</option>
                        <option value="ISTRA 20%">ISTRA 20%</option>
                        <option value="QUALITAS">QUALITAS</option>
                        <option value="ABA">ABA</option>
                        <option value="AFIRME">AFIRME</option>
                        <option value="AIG">AIG</option>
                        <option value="AXA">AXA</option>
                        <option value="GNP">GNP</option>
                        <option value="HDI">HDI</option>
                        <option value="SURA">SURA</option>
                        <option value="MAPFRE">MAPFRE</option>
                        <option value="ZURICH">ZURICH</option>
                        <option value="SANTANA">SANTANA</option>
                        <option value="QUALITAS 15% Y 20%">QUALITAS 15% Y 20%</option>
                        <option value="GNP 20%">GNP 20%</option>
                        <option value="HDI 20%">HDI 20%</option>
                        <option value="Otros">Otros</option>
                      </select>
                    </div>
                  </div>
                   <input id="input-id" type="hidden" name="fs[id]" value="">
              </div>


            </div>
        </div>
    </div>
  </div>
</div>



<!-- FIN DEL CUARTO FORMULARIO -->

<div class="row">
  <div class="col-sm-12">
          <div>
            <button class="btn btn-sm btn-primary text-center m-t-n-xs" type="submit"><strong>Enviar </strong></button>
          </div>
    
    </div>
  </div>
</form>
         </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
      </div>
    </div>

  </div>
</div>

<!-- Modal end -->