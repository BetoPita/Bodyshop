
<h2>Bitacora de negocios - Búsquedas Inteligentes</h2>

<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,600,400' rel='stylesheet' type='text/css'>

<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.css" />
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>statics/js/modules/jsgrid/theme.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/cupertino/jquery-ui.css">

<link rel="stylesheet" href="<?php echo base_url();?>statics/css/custom/isloading.css">
<link rel="stylesheet" href="<?php echo base_url();?>statics/css/custom/style.css">
 <script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>


 <script src="<?php echo base_url();?>statics/js/custom/moment.js"></script>

<script src="<?php echo base_url();?>statics/js/modules/bootstrap-datetimepicker.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>


<script src="<?php echo base_url();?>statics/js/custom/bootbox.min.js"></script>
<script src="<?php echo base_url();?>statics/js/custom/general.js"></script>
<script src="<?php echo base_url();?>statics/js/custom/isloading.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/js/select2.min.js"></script>
<form action="" method="POST" id="frm">
  <input type="hidden" id="abuscar" name="abuscar" value="">
  <input type="hidden" id="nombre_grafica" name="nombre_grafica" value="">
<div class="row">
   <div class="col-sm-3 form-group">
    <label>Tipo de Búsqueda</label>
    <select name="tipo_busqueda" id="tipo_busqueda" class="form-control tipo_busquedas">
        <option value="">-- Selecciona -- </option>
        <option value="asesor">Asesor</option>
        <option value="nombre_cliente">Nombre del cliente</option>
        <option value="propuesta_folio_contrato">Folio Propuesta</option>
        <option value="financiera">Financiera</option>
        <option value="status">Estatus</option>
        <option value="fecha_recepcion_docs">Fecha de recepción de dcts.</option>
        <option value="fecha_condicionamiento">Fecha de condicionamiento</option>
        <option value="fecha_cumplimiento">Fecha de cumplimiento</option>
        <option value="fecha_aprobacion">Fecha de aprobación</option>
        <option value="fecha_contrato">Fecha de contrato</option>
        <option value="fecha_compra">Fecha de compra</option>
    </select>
   </div>
   <div id="div_asesor" class="col-sm-3 div_ocultar">
     <label>Asesor</label>
     <?php echo $drop_asesores ?>
   </div>
    <div id="div_nombre_cliente" class="col-sm-3 div_ocultar form-group">
     <label>Cliente</label>
     <?php echo $drop_clientes ?>
   </div>
    <div id="div_propuesta_folio_contrato" class="col-sm-2 div_ocultar">
     <label>Folio Propuesta</label>
     <input type="text" name="folio_propuesta" id="folio_propuesta" class="form-control llenar_busqueda">
   </div>
    <div id="div_financiera" class="col-sm-3 div_ocultar">
     <label>Financiera</label>
     <?php echo $drop_financiera ?>
   </div>
    <div id="div_status" class="col-sm-3 div_ocultar">
     <label>Estatus</label>
     <?php echo $drop_status ?>
   </div>
   <div id="div_fechas">
       <div class='col-md-2'>
        <label>Fecha Inicio</label>
          <div class="form-group">
              <div class='input-group date' id='datetimepicker6'>
                  <input type='text' name="finicio" id="finicio" class="form-control" />
                  <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                  </span>
              </div>
          </div>
      </div>
      <div class='col-md-2'>
        <label>Fecha Fin</label>
          <div class="form-group">
              <div class='input-group date' id='datetimepicker7'>
                  <input type='text' name="ffin" id="ffin" class="form-control" />
                  <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                  </span>
              </div>
          </div>
      </div>
   </div>
    <div id="div_fechas_principales">
       <div class="col-sm-2 form-group">
           <label>Año</label>
            <div class="form-group">
                <div class='input-group date' id='datetimepicker_anio'>
                      <input type="text" name="anio" id="anio" class="form-control">
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
       </div>
       <div class="col-sm-2 form-group">
           <label>Mes</label>
           <div class="form-group">
                <div class='input-group date' id='datetimepicker_mes'>
                      <input type="text" name="mes" id="mes" class="form-control">
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
       </div>
    </div>
   <div class="col-sm-2 form-group">
      <button type="button" id="buscar" style="margin-top: 25px;" class="btn btn-success">Buscar</button>
   </div>
</div>
</form>
<div class="row">
    <div class="col-sm-12">
        <div id="div_busqueda">
            
        </div>
        
    </div>
</div>
<script type="text/javascript">
    $(function () {
       $('#datetimepicker_anio').datetimepicker({
           format: 'YYYY',
           locale: 'es'
        });
       $('#datetimepicker_mes').datetimepicker({
           format: "MMM",
            viewMode: "months",
            locale: 'es'
        });
        $('#datetimepicker6').datetimepicker({
           format: 'DD/MM/YYYY'
        });
        $('#datetimepicker7').datetimepicker({
            useCurrent: true, //Important! See issue #1075
            format: 'DD/MM/YYYY'
        });
        $("#datetimepicker6").on("dp.change", function (e) {
          console.log($('#datetimepicker7').data("DateTimePicker").minDate(e.date));
            $('#datetimepicker7').data("DateTimePicker").minDate(e.date);
        });
        $("#datetimepicker7").on("dp.change", function (e) {
           console.log($('#datetimepicker6').data("DateTimePicker").maxDate(e.date));
            $('#datetimepicker6').data("DateTimePicker").maxDate(e.date);
        });
    });
</script>
<script>
var site_url = "<?php echo site_url() ?>";

ocultar();
$(".busqueda").select2()
$(".tipo_busquedas").on('change',function(){
    $(".div_ocultar").hide('slow');
   $("#div_"+$(this).val()).show('slow');
   $("#abuscar").val("");
   if(validarSelect($(this).val())){
      $("#div_fechas_principales").hide('slow');
      $("#div_fechas").show('slow');
   }else{
      $("#div_fechas_principales").show('slow');
      $("#div_fechas").hide('slow');
   }
   $("#nombre_grafica").val($("#tipo_busqueda option:selected").text());
   $("#div_busqueda").empty();
   $(".busqueda").select2({
      width:"100%"
   })
});

$(".llenar_busqueda_select").on('change',function(){
    $("#abuscar").val($(this).val())
});
$(".llenar_busqueda").on('change',function(){
    $("#abuscar").val($(this).val())
    $("#nombre_grafica").val($("#tipo_busqueda option:selected").text());
});
 $("#buscar").on('click',function(){
        buscar();
    });
 function buscar(){
        if(validarSelect($("#tipo_busqueda").val())){
          var url =site_url+"/bitacora_negocios/mostrar_graficas/2";
          if($("#tipo_busqueda").val()==''){
               ErrorCustom('Es necesario ingresar el tipo de búsqueda');
          }else if($("#finicio").val()==''){
               ErrorCustom('Es necesario ingresar la fecha inicio');
          }else if($("#ffin").val()==''){
               ErrorCustom('Es necesario la fecha de fin');
          }else{
            ajaxLoad(url,$("#frm").serialize(),"div_busqueda","POST",function(result){
          
            });
          }
        }else{
          var url =site_url+"/bitacora_negocios/mostrar_graficas/1";
          if($("#tipo_busqueda").val()==''){
               ErrorCustom('Es necesario ingresar el tipo de búsqueda');
          }else if($("#abuscar").val()==''){
            ErrorCustom('Es necesario ingresar el campo a buscar');
          }else if($("#anio").val()==''){
              ErrorCustom('Es necesario ingresar el año');
          }else {
            ajaxLoad(url,$("#frm").serialize(),"div_busqueda","POST",function(result){
          
            });
          }
        }
        
    }
  function ocultar(){
    $("#div_asesor").hide();
    $("#div_nombre_cliente").hide();
    $("#div_propuesta_folio_contrato").hide();
    $("#div_financiera").hide();
    $("#div_status").hide();
    $("#div_fechas").hide();

    
  }
  function validarSelect(valor){
    if(valor=='fecha_recepcion_docs' || valor=='fecha_condicionamiento' || valor=='fecha_cumplimiento' || valor=='fecha_aprobacion' || valor=='fecha_contrato' || valor=='fecha_compra'){
       return true;
    }else{
      return false;
    }
  }
</script>


