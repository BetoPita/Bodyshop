  


<h2>Bitacora de negocios - Busquedas</h2>

<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,600,400' rel='stylesheet' type='text/css'>

<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.css" />
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>statics/js/modules/jsgrid/theme.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/cupertino/jquery-ui.css">

 <script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.core.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.load-indicator.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.load-strategies.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.sort-strategies.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.field.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.field.text.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.field.number.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.field.select.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.field.checkbox.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>statics/js/modules/jsgrid/jsgrid.field.control.js" ></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>

<script src="<?php echo base_url();?>statics/js/modules/bootstrap-datetimepicker.js"></script>


<script type="text/javascript">

var registros =    <?php Print($json_registros); ?>;  
var asesores =    <?php Print($json_asesores); ?>;  
var horas =    <?php Print($json_horas); ?>;
var financieras =    <?php Print($json_financieras); ?>;  
var estatus =    <?php Print($json_estatus); ?>; 
var aseguradoras =    <?php Print($json_aseguradoras); ?>;  
var comisiones =    <?php Print($json_comisiones); ?>; 
var udis =    <?php Print($json_udi); ?>; 
var modelos =    <?php Print($json_modelos); ?>; 

horas.reverse();

asesores.unshift({
            "id": "0",
            "nombre":""
  
        });
horas.unshift({
            "id": "0",
            "hora":""
  
        });

financieras.unshift({
            "id": 0,
            "nombre":""
  
        });

estatus.unshift({
            "id": 0,
            "nombre":""
  
        });

udis.unshift({
            "id": 0,
            "valor":""
  
        });

aseguradoras.unshift({
            "id": 0,
            "nombre":""
  
        });
comisiones.unshift({
            "id": 0,
            "valor":""
  
        });

modelos.unshift({
            "id": 0,
            "modelo":""
  
        });


/*for (var key in asesores) {
    if (asesores.hasOwnProperty(key)) {

         //alert("EL TIPO DE ID ES  " + typeof(asesores[key].id));
      
      var idAux = asesores[key].id;
    
          asesores[key].id = parseInt(idAux);
   

     // alert("EL TIPO DE ID ES AHORA " + typeof(asesores[key].id));
   }
}*/



  var db = {

        loadData: function(filter) {
            return $.grep(this.registros, function(registro) {
                return (!filter.no || registro.no === filter.no)
                    //&& (!filter.asesor || registro.asesor === filter.asesor )
                    && (!filter.asesor || registro.asesor.indexOf(filter.asesor)  > -1)
                    && (!filter.nombre_cliente || registro.nombre_cliente.indexOf(filter.nombre_cliente) > -1)
                    && (!filter.tel_casa || registro.tel_casa.indexOf(filter.tel_casa) > -1)
                    && (!filter.movil || registro.movil.indexOf(filter.movil) > -1)
                    && (!filter.tel_oficina || registro.tel_oficina.indexOf(filter.tel_oficina) > -1)
                    && (!filter.correo_electronico || registro.correo_electronico.indexOf(filter.correo_electronico) > -1)
                    && (!filter.mes || registro.mes.indexOf(filter.mes) > -1)

                    && (!filter.fecha_recepcion_docs.from || new Date(registro.fecha_recepcion_docs) >= filter.fecha_recepcion_docs.from) 
                    && (!filter.fecha_recepcion_docs.to || new Date(registro.fecha_recepcion_docs) <= filter.fecha_recepcion_docs.to)

                    && (!filter.hora_recepcion_docs || registro.hora_recepcion_docs.indexOf(filter.hora_recepcion_docs) > -1)
                    && (!filter.hora_inicio_analisis || registro.hora_inicio_analisis.indexOf(filter.hora_inicio_analisis) > -1)
                    && (!filter.comentarios || registro.comentarios.indexOf(filter.comentarios) > -1)
                    //&& (!filter.modelos || registro.modelos === filter.modelos)
                    && (!filter.modelo || registro.modelo.indexOf(filter.modelo) > -1)
                    && (!filter.catalogo || registro.catalogo.indexOf(filter.catalogo) > -1)
                    && (!filter.financiera || registro.financiera.indexOf(filter.financiera) > -1)
                    && (!filter.status || registro.status.indexOf(filter.status) > -1)
                    && (!filter.propuesta_folio_contrato || registro.propuesta_folio_contrato.indexOf(filter.propuesta_folio_contrato) > -1)

                    && (!filter.fecha_condicionamiento.from || new Date(registro.fecha_condicionamiento) >= filter.fecha_condicionamiento.from) 
                    && (!filter.fecha_condicionamiento.to || new Date(registro.fecha_condicionamiento) <= filter.fecha_condicionamiento.to)

                    && (!filter.hora_condicion || registro.hora_condicion.indexOf(filter.hora_condicion) > -1)

                    && (!filter.fecha_cumplimiento.from || new Date(registro.fecha_cumplimiento) >= filter.fecha_cumplimiento.from) 
                    && (!filter.fecha_cumplimiento.to || new Date(registro.fecha_cumplimiento) <= filter.fecha_cumplimiento.to)

                    && (!filter.hora_cumplimiento || registro.hora_cumplimiento.indexOf(filter.hora_cumplimiento) > -1)

                    && (!filter.fecha_aprobacion.from || new Date(registro.fecha_aprobacion) >= filter.fecha_aprobacion.from) 
                    && (!filter.fecha_aprobacion.to || new Date(registro.fecha_aprobacion) <= filter.fecha_aprobacion.to)

                    && (!filter.hora_aprobacion || registro.hora_aprobacion.indexOf(filter.hora_aprobacion) > -1)

                    && (!filter.fecha_contrato.from || new Date(registro.fecha_contrato) >= filter.fecha_contrato.from) 
                    && (!filter.fecha_contrato.to || new Date(registro.fecha_contrato) <= filter.fecha_contrato.to)

                    && (!filter.hora_contrato || registro.hora_contrato.indexOf(filter.hora_contrato) > -1)

                    && (!filter.fecha_compra.from || new Date(registro.fecha_compra) >= filter.fecha_compra.from) 
                    && (!filter.fecha_compra.to || new Date(registro.fecha_compra) <= filter.fecha_compra.to)

                    && (!filter.hora_compra || registro.hora_compra.indexOf(filter.hora_compra) > -1)
                    && (!filter.nombre_plan || registro.nombre_plan.indexOf(filter.nombre_plan) > -1)
                    && (!filter.bono_fc || registro.bono_fc.indexOf(filter.bono_fc) > -1)
                    && (!filter.plazo || registro.plazo.indexOf(filter.plazo) > -1)
                    && (!filter.precio_unidad || registro.precio_unidad.indexOf(filter.precio_unidad) > -1)
                    && (!filter.enganche || registro.enganche.indexOf(filter.enganche) > -1)
                    && (!filter.monto_financiar || registro.monto_financiar.indexOf(filter.monto_financiar) > -1)
                    && (!filter.comision || registro.comision.indexOf(filter.comision) > -1)
                    && (!filter.comision_agencia || registro.comision_agencia.indexOf(filter.comision_agencia) > -1)
                    && (!filter.comision_asesor || registro.comision_asesor.indexOf(filter.comision_asesor) > -1)
                    && (!filter.tipo_seguro || registro.tipo_seguro.indexOf(filter.tipo_seguro) > -1)
                    && (!filter.compania_seg || registro.compania_seg.indexOf(filter.compania_seg) > -1)
                    && (!filter.no_poliza || registro.no_poliza.indexOf(filter.no_poliza) > -1)

                   && (!filter.inicio_vigencia.from || new Date(registro.inicio_vigencia) >= filter.inicio_vigencia.from) 
                    && (!filter.inicio_vigencia.to || new Date(registro.inicio_vigencia) <= filter.inicio_vigencia.to)


                    && (!filter.vencimiento_anual.from || new Date(registro.vencimiento_anual) >= filter.vencimiento_anual.from) 
                    && (!filter.vencimiento_anual.to || new Date(registro.vencimiento_anual) <= filter.vencimiento_anual.to)

                    && (!filter.prima_total || registro.prima_total.indexOf(filter.prima_total) > -1)
                    && (!filter.iva || registro.iva.indexOf(filter.iva) > -1)

                    && (!filter.emision.from || new Date(registro.emision) >= filter.emision.from) 
                    && (!filter.emision.to || new Date(registro.emision) <= filter.emision.to)

                    && (!filter.udi || registro.udi.indexOf(filter.udi) > -1)
                    && (!filter.udi_agencia || registro.udi_agencia.indexOf(filter.udi_agencia) > -1)
                    && (!filter.udi_asesor || registro.udi_asesor.indexOf(filter.udi_asesor) > -1);
                   
            });
        }


       /* loadData: function(filter) {
            return $.grep(this.clients, function(client) {
                return (!filter.Name || client.Name.indexOf(filter.Name) > -1)
                    && (!filter.Age || client.Age === filter.Age)
                    && (!filter.Address || client.Address.indexOf(filter.Address) > -1)
                    && (!filter.Country || client.Country === filter.Country)
                    && (filter.Married === undefined || client.Married === filter.Married);
            });
        },*/

       /* insertItem: function(insertingClient) {
            this.clients.push(insertingClient);
        },

        updateItem: function(updatingClient) { },

        deleteItem: function(deletingClient) {
            var clientIndex = $.inArray(deletingClient, this.clients);
            this.clients.splice(clientIndex, 1);
        }*/

    };

     window.db = db;


      db.registros = registros;
      db.asesores = asesores;
      db.horas = horas;
      db.financieras = financieras;
      db.estatus = estatus;
      db.aseguradoras = aseguradoras;
      db.comisiones = comisiones;
      db.udis = udis;
      db.modelos = modelos;






      $(function() {






var DateField = function(config) {
    jsGrid.Field.call(this, config);
};

DateField.prototype = new jsGrid.Field({
    sorter: function(date1, date2) {
        return new Date(date1) - new Date(date2);
    },    
    
    itemTemplate: function(value) {
        return new Date(value).toDateString();
    },
    
    filterTemplate: function() {
            var grid = this._grid;
    
        var now = new Date();
        this._fromPicker = $("<input>").datepicker({ defaultDate: now.setFullYear(now.getFullYear() - 1) });
        this._toPicker = $("<input>").datepicker({ defaultDate: now.setFullYear(now.getFullYear() + 1) });
        
        this._fromPicker.on("keypress", function(e) {
                    if(e.which === 13) {
                        grid.search();
                        e.preventDefault();
                    }
                });
                
        this._toPicker.on("keypress", function(e) {
                    if(e.which === 13) {
                        grid.search();
                        e.preventDefault();
                    }
                });     
        
        return $("<div>").append(this._fromPicker).append(this._toPicker);
    },
    
    insertTemplate: function(value) {
        return this._insertPicker = $("<input>").datepicker({ defaultDate: new Date() });
    },
    
    editTemplate: function(value) {
        return this._editPicker = $("<input>").datepicker().datepicker("setDate", new Date(value));
    },
    
    insertValue: function() {
        return this._insertPicker.datepicker("getDate").toISOString();
    },
    
    editValue: function() {
        return this._editPicker.datepicker("getDate").toISOString();
    },
    
    filterValue: function() {
        return {
            from: this._fromPicker.datepicker("getDate"),
            to: this._toPicker.datepicker("getDate")
        };
    }
});

jsGrid.fields.date = DateField;




            //jsGrid.fields.myDateField = MyDateField;



            $("#jsGrid").jsGrid({
                height: "70%",
                width: "100%",
                filtering: true,
                editing: true,
                sorting: true,
                paging: true,
                autoload: true,
                pageSize: 15,
                pageButtonCount: 5,
                deleteConfirm: "Do you really want to delete the client?",
                controller: db,
                fields: [
                    { name: "no", type: "text", width: 150 },
                    { name: "asesor", type: "select", items: db.asesores, valueField: "id", textField: "nombre", valueType: "string"},
                    { name: "nombre_cliente", type: "text", width: 200 },
                    { name: "tel_casa", type: "text", width: 150  },
                    { name: "movil", type: "text", width: 150  },
                    { name: "tel_oficina", type: "text", width: 150  },
                    { name: "correo_electronico", type: "text", width: 150  },
                    { name: "mes", type: "text", width: 150  },
                    { name: "fecha_recepcion_docs", type: "date", width: 150  },
                    { name: "hora_recepcion_docs", type: "select", width: 250 , items: db.horas, valueField: "id", textField: "hora", valueType: "string"},
                    { name: "hora_inicio_analisis", type: "select", width: 250 , items: db.horas, valueField: "id", textField: "hora"},
                    { name: "comentarios", type: "text", width: 200 },
                    { name: "modelo", type: "select", width: 250 , items: db.modelos, valueField: "id", textField: "modelo"},
                    { name: "catalogo", type: "text", width: 200 },
                    { name: "financiera", type: "select", width: 250 , items: db.financieras, valueField: "id", textField: "nombre"},
                    { name: "status", type: "select", width: 150 , items: db.estatus, valueField: "id", textField: "nombre"},
                    { name: "propuesta_folio_contrato", type: "text", width: 200 },
                    { name: "fecha_condicionamiento", type: "date", width: 150  },
                    { name: "hora_condicion", type: "select", width: 250 , items: db.horas, valueField: "id", textField: "hora"},
                    { name: "fecha_cumplimiento", type: "date", width: 150  },
                    { name: "hora_cumplimiento", type: "select", width: 250 , items: db.horas, valueField: "id", textField: "hora"},
                    { name: "fecha_aprobacion", type: "date", width: 150  },
                    { name: "hora_aprobacion", type: "select", width: 250 , items: db.horas, valueField: "id", textField: "hora"},
                    { name: "fecha_contrato", type: "date", width: 150  },
                    { name: "hora_contrato", type: "select", width: 250 , items: db.horas, valueField: "id", textField: "hora"},
                    { name: "fecha_compra", type: "date", width: 150  },
                    { name: "hora_compra", type: "select", width: 250 , items: db.horas, valueField: "id", textField: "hora"},
                    { name: "nombre_plan", type: "text", width: 200 },
                    { name: "bono_fc", type: "text", width: 200 },
                    { name: "plazo", type: "text", width: 200 },
                    { name: "precio_unidad", type: "text", width: 200 },
                    { name: "enganche", type: "text", width: 200 },
                    { name: "monto_financiar", type: "text", width: 200 },
                    { name: "comision", type: "select", width: 250 , items: db.comisiones, valueField: "id", textField: "valor"},
                    { name: "comision_agencia", type: "text", width: 200 },
                    { name: "comision_asesor", type: "text", width: 200 },
                    { name: "tipo_seguro", type: "text", width: 200 },
                    { name: "compania_seg", type: "select", width: 250 , items: db.aseguradoras, valueField: "id", textField: "nombre"},
                    { name: "no_poliza", type: "text", width: 200 },
                    { name: "inicio_vigencia", type: "date", width: 150  },
                    { name: "vencimiento_anual", type: "date", width: 150  },
                    { name: "prima_total", type: "text", width: 200  },
                    { name: "iva", type: "text", width: 200   },
                    { name: "emision", type: "date", width: 150  },
                    { name: "udi", type: "select", width: 250 , items: db.udis, valueField: "id", textField: "valor"},
                    { name: "udi_agencia", type: "text", width: 150  },
                    { name: "udi_asesor", type: "text", width: 150  },
                    { type: "control" }
                ]
            });

        });

     $(document).ready(function(){

         $(".jsgrid-grid-body").css("height","300px");
         $(".jsgrid-delete-button").css("visibility","hidden");
         console.log(db);


       

     });

</script>
<style type="text/css">

.jsgrid-grid-header,
.jsgrid-grid-body{
  overflow: auto;
}
    
</style>



   
        <div class="row">
          <div id="section-recibido" class="col-sm-12">
              <div id="jsGrid"></div>
          </div>
        </div>



