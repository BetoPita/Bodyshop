


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tablero de estatus</title>
     <script src="http://code.jquery.com/jquery.js"></script>
    <link href="<?php echo base_url();?>statics/css/tema/css/bootstrap.min.css" rel="stylesheet">

    <!-- CSS de Bootstrap -->


    <!-- librerías opcionales que activan el soporte de HTML5 para IE8 -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <script>

      $(document).ready(function(){

         var records =    <?php Print($json); ?>;
         var postit="";

         for (i = 0; i < records.length; i++) {
             postit += "<div class='row postit'>";
             postit += "    <div class='col-sm-6'>Asesor</div>" + "<div class='col-sm-6'>" + records[i].asesor + "</div>";
             postit += "    <div class='col-sm-6'>Nombre</div>" + "<div class='col-sm-6'>" + records[i].nombre_cliente + "</div>";
             postit += "    <div class='col-sm-6'>Estatus</div>" + "<div class='col-sm-6'>" + records[i].status + "</div>";
             postit += "    <div class='col-sm-6'>Fecha</div>" + "<div class='col-sm-6'>" + records[i].fecha_recepcion_docs + "</div>";
             postit += "    <div class='col-sm-6'>Hora</div>" + "<div class='col-sm-6'>" + records[i].hora_recepcion_docs + "</div>";
             postit += "</div>";



             switch(records[i].status) {
                  case "Recibido":
                   $('#section-recibido').append(postit);
                   break;
                 case "Análisis":
                   $('#section-analisis').append(postit);
                   break;
                case "Condición":
                   $('#section-condicion').append(postit);
                   break;
                case "En Reconsideración":
                   $('#section-reconsideracion').append(postit);
                   break;
                 case "Aprobado":
                   $('#section-aprobado').append(postit);
                   break;
                case "Contrato Generado":
                   $('#section-contrato').append(postit);
                   break;
                case "Validación Enganche":
                   $('#section-validacion').append(postit);
                   break;
                 case "Pago Plan piso":
                   $('#section-pago').append(postit);
                   break;
                 case "Envio Compra":
                   $('#section-envio').append(postit);
                   break;
                 case "Rechazo":
                   $('#section-rechazo').append(postit);
                   break;
                 case "Comprada":
                   $('#section-comprada').append(postit);
                   break;
                case "Canceló":
                   $('#section-cancelo').append(postit);
                   break;
                 case "Refacturación":
                   $('#section-refacturacion').append(postit);
                   break;
                 case "Desembolso":
                   $('#section-desembolso').append(postit);
                   break;
                default:
                   text = "Nada";
             }

             postit = "";


         }

        // $('#nada').html(postit);

        //$( "#columns-parent" ).scrollTop( 50 );
        //window.scrollTo(0, 100);

        var aux1 = $(window).height();   //solo la pantalla
       var aux2 = $(document).height(); //de la pantalla completa con scroll
      var inicio = 100;
       setInterval(function(){
          window.scrollTo(0, inicio);
          if(inicio > aux2){
              inicio = 0;
          }else{
            inicio = inicio +400;
          }

        },15000);


       });



      </script>

  <style>

  .postit{


     background: #7f8c8d;
      margin-right: 0px;
     margin-left: 0px;
     color:#fff;

  }

  .row{
  	 margin-top: 10px;
  }

      .sections-header{

      	background: #27ae60;
      	padding-top: 10px;
      	padding-bottom: 10px;
      	text-align: center;

      }

body{
  background: #34495e;



}

   </style>
  </head>
  <body>


    <div id="nada"></div>

    <div id="wrapper">

      <div id="columns-parent">
        <div class="row">
          <div id="section-recibido" class="col-sm-2"><div class="sections-header">Recibido</div></div>
          <div id="section-analisis" class="col-sm-2"><div class="sections-header">Análisis</div></div>
          <div id="section-condicion" class="col-sm-2"><div class="sections-header">Condicion</div></div>
          <div id="section-reconsideracion" class="col-sm-2"><div class="sections-header">Reconsideración</div></div>
          <div id="section-aprobado" class="col-sm-2"><div class="sections-header">Aprobado</div></div>
          <div id="section-contrato" class="col-sm-2"><div class="sections-header">Contrato Generado</div></div>
        </div>
        <div class="row">
          <div id="section-validacion" class="col-sm-2"><div class="sections-header">Validación enganche</div></div>
          <div id="section-pago" class="col-sm-2"><div class="sections-header">Pago plan piso</div></div>
          <div id="section-envio" class="col-sm-2"><div class="sections-header">Envío compra</div></div>
          <div id="section-rechazo" class="col-sm-2"><div class="sections-header">Rechazo</div></div>
          <div id="section-comprada" class="col-sm-2"><div class="sections-header">Comprada</div></div>
          <div id="section-cancelo" class="col-sm-2"><div class="sections-header">Canceló</div></div>
        </div>
        <div class="row">
           <div id="section-refacturacion" class="col-sm-2"><div class="sections-header">Refacturación</div></div>
           <div id="section-desembolso" class="col-sm-2"><div class="sections-header">Desembolso</div></div>
        </div>
      </div>

    </div>


    <!-- Librería jQuery requerida por los plugins de JavaScript -->


  </body>
</html>
